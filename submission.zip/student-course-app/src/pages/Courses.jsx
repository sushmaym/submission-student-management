import { useEffect } from "react";
import { useApp } from "../context/AppContext.jsx";
import CourseForm from "../components/CourseForm.jsx";
import Card from "../components/Card.jsx";

export default function Courses() {
  const { courses, students, deleteCourse } = useApp();
  useEffect(() => { document.title = `Courses (${courses.length})`; }, [courses.length]);

  return (
    <>
      <h2 className="mb-3">Courses</h2>
      <CourseForm />
      <div className="row g-3">
        {courses.map((c) => (
          <div key={c.id} className="col-12 col-md-6 col-lg-4">
            <Card title={c.title} subtitle={`Instructor: ${c.instructor}`} onDelete={() => deleteCourse(c.id)}>
              <p className="mb-1">Credits: {c.credits}</p>
              <p className="mb-0">Enrolled: {students.filter((s) => s.courseId === c.id).length}</p>
            </Card>
          </div>
        ))}
      </div>
    </>
  );
}
