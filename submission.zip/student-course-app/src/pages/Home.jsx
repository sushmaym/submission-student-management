import { Link } from "react-router-dom";
import { useApp } from "../context/AppContext.jsx";

export default function Home() {
  const { students, courses } = useApp();
  return (
    <>
      <h2 className="mb-4">Dashboard</h2>
      <div className="row g-3">
        <div className="col-12 col-sm-6">
          <div className="card text-bg-primary shadow-sm"><div className="card-body">
            <h1>{students.length}</h1><p className="mb-2">Students</p>
            <Link className="btn btn-light btn-sm" to="/students">Manage</Link>
          </div></div>
        </div>
        <div className="col-12 col-sm-6">
          <div className="card text-bg-success shadow-sm"><div className="card-body">
            <h1>{courses.length}</h1><p className="mb-2">Courses</p>
            <Link className="btn btn-light btn-sm" to="/courses">Manage</Link>
          </div></div>
        </div>
      </div>
    </>
  );
}
