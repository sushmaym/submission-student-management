import { useEffect, useState } from "react";
import { useApp } from "../context/AppContext.jsx";
import StudentForm from "../components/StudentForm.jsx";
import Card from "../components/Card.jsx";

export default function Students() {
  const { students, courses, deleteStudent } = useApp();
  const [search, setSearch] = useState("");

  useEffect(() => { document.title = `Students (${students.length})`; }, [students.length]);

  const filtered = students.filter((s) => s.name.toLowerCase().includes(search.toLowerCase()));
  const courseName = (id) => courses.find((c) => c.id === id)?.title ?? "Not enrolled";

  return (
    <>
      <h2 className="mb-3">Students</h2>
      <StudentForm />
      <input className="form-control mb-3" placeholder="Search students..." value={search} onChange={(e) => setSearch(e.target.value)} />
      <div className="row g-3">
        {/* List rendering: each item needs a unique key */}
        {filtered.map((s) => (
          <div key={s.id} className="col-12 col-md-6 col-lg-4">
            <Card title={s.name} subtitle={s.email} onDelete={() => deleteStudent(s.id)}>
              Course: <span className="badge bg-info text-dark">{courseName(s.courseId)}</span>
            </Card>
          </div>
        ))}
        {filtered.length === 0 && <p className="text-muted">No students found.</p>}
      </div>
    </>
  );
}
