export const initialCourses = [
  { id: 1, title: "React Fundamentals", instructor: "Dr. Rao", credits: 4 },
  { id: 2, title: "Database Systems", instructor: "Prof. Iyer", credits: 3 },
  { id: 3, title: "Cloud Computing", instructor: "Dr. Menon", credits: 3 },
];
export const initialStudents = [
  { id: 1, name: "Anita Sharma", email: "anita@example.com", courseId: 1 },
  { id: 2, name: "Ravi Kumar", email: "ravi@example.com", courseId: 2 },
];
