import { NavLink } from "react-router-dom";

export default function NavBar() {
  const link = ({ isActive }) => "nav-link" + (isActive ? " active fw-bold" : "");
  return (
    <nav className="navbar navbar-expand-md navbar-dark bg-primary">
      <div className="container">
        <span className="navbar-brand">🎓 CourseManager</span>
        <button className="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#nav">
          <span className="navbar-toggler-icon" />
        </button>
        <div className="collapse navbar-collapse" id="nav">
          <div className="navbar-nav ms-auto">
            <NavLink to="/" end className={link}>Home</NavLink>
            <NavLink to="/students" className={link}>Students</NavLink>
            <NavLink to="/courses" className={link}>Courses</NavLink>
          </div>
        </div>
      </div>
    </nav>
  );
}
