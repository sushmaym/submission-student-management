// Reusable card: demonstrates props (title, subtitle, children, onDelete)
export default function Card({ title, subtitle, children, onDelete }) {
  return (
    <div className="card card-item h-100 shadow-sm">
      <div className="card-body">
        <h5 className="card-title">{title}</h5>
        {subtitle && <h6 className="card-subtitle mb-2 text-muted">{subtitle}</h6>}
        <div className="card-text">{children}</div>
      </div>
      {onDelete && (
        <div className="card-footer bg-white border-0">
          <button className="btn btn-sm btn-outline-danger" onClick={onDelete}>Delete</button>
        </div>
      )}
    </div>
  );
}
