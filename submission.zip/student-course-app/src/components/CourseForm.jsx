import { useState } from "react";
import { useApp } from "../context/AppContext.jsx";

export default function CourseForm() {
  const { addCourse } = useApp();
  const [form, setForm] = useState({ title: "", instructor: "", credits: 3 });

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!form.title.trim() || !form.instructor.trim()) return;
    addCourse({ ...form, credits: Number(form.credits) });
    setForm({ title: "", instructor: "", credits: 3 });
  };

  return (
    <form onSubmit={handleSubmit} className="card card-body shadow-sm mb-4">
      <h5>Add Course</h5>
      <div className="row g-2">
        <div className="col-12 col-md-4">
          <input className="form-control" name="title" placeholder="Course title" value={form.title} onChange={handleChange} />
        </div>
        <div className="col-12 col-md-4">
          <input className="form-control" name="instructor" placeholder="Instructor" value={form.instructor} onChange={handleChange} />
        </div>
        <div className="col-6 col-md-3">
          <input type="number" min="1" max="6" className="form-control" name="credits" value={form.credits} onChange={handleChange} />
        </div>
        <div className="col-6 col-md-1 d-grid">
          <button className="btn btn-primary">Add</button>
        </div>
      </div>
    </form>
  );
}
