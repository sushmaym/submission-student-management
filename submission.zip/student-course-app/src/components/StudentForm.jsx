import { useState } from "react";
import { useApp } from "../context/AppContext.jsx";

export default function StudentForm() {
  const { courses, addStudent } = useApp();
  // Controlled form: state holds the input values
  const [form, setForm] = useState({ name: "", email: "", courseId: "" });
  const [error, setError] = useState("");

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!form.name.trim() || !/\S+@\S+\.\S+/.test(form.email)) {
      setError("Enter a name and a valid email.");
      return;
    }
    addStudent({ ...form, courseId: form.courseId ? Number(form.courseId) : null });
    setForm({ name: "", email: "", courseId: "" });
    setError("");
  };

  return (
    <form onSubmit={handleSubmit} className="card card-body shadow-sm mb-4">
      <h5>Add Student</h5>
      {error && <div className="alert alert-danger py-1">{error}</div>}
      <div className="row g-2">
        <div className="col-12 col-md-4">
          <input className="form-control" name="name" placeholder="Name" value={form.name} onChange={handleChange} />
        </div>
        <div className="col-12 col-md-4">
          <input className="form-control" name="email" placeholder="Email" value={form.email} onChange={handleChange} />
        </div>
        <div className="col-12 col-md-3">
          <select className="form-select" name="courseId" value={form.courseId} onChange={handleChange}>
            <option value="">No course</option>
            {courses.map((c) => (
              <option key={c.id} value={c.id}>{c.title}</option>
            ))}
          </select>
        </div>
        <div className="col-12 col-md-1 d-grid">
          <button className="btn btn-primary">Add</button>
        </div>
      </div>
    </form>
  );
}
