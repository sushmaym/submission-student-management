import { createContext, useContext, useEffect, useState } from "react";
import { initialCourses, initialStudents } from "../data/initialData.js";

const AppContext = createContext(null);

// Read saved data from localStorage, or fall back to defaults
const load = (key, fallback) => {
  try {
    const saved = localStorage.getItem(key);
    return saved ? JSON.parse(saved) : fallback;
  } catch {
    return fallback;
  }
};

export function AppProvider({ children }) {
  const [students, setStudents] = useState(() => load("students", initialStudents));
  const [courses, setCourses] = useState(() => load("courses", initialCourses));

  // useEffect: persist data whenever it changes
  useEffect(() => localStorage.setItem("students", JSON.stringify(students)), [students]);
  useEffect(() => localStorage.setItem("courses", JSON.stringify(courses)), [courses]);

  const addStudent = (s) => setStudents((prev) => [...prev, { ...s, id: Date.now() }]);
  const deleteStudent = (id) => setStudents((prev) => prev.filter((s) => s.id !== id));
  const addCourse = (c) => setCourses((prev) => [...prev, { ...c, id: Date.now() }]);
  const deleteCourse = (id) => {
    setCourses((prev) => prev.filter((c) => c.id !== id));
    setStudents((prev) => prev.map((s) => (s.courseId === id ? { ...s, courseId: null } : s)));
  };

  const value = { students, courses, addStudent, deleteStudent, addCourse, deleteCourse };
  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

// Custom hook: const { students } = useApp();
export const useApp = () => useContext(AppContext);
