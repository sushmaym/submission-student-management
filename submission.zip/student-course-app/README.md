# Student Course Management (React + Vite + Bootstrap)

## Run
    npm install
    npm run dev      # open http://localhost:5173

## Project structure
    student-course-app/
    ├── index.html              # HTML shell with <div id="root">
    ├── package.json            # dependencies and scripts
    ├── vite.config.js          # Vite + React plugin
    └── src/
        ├── main.jsx            # entry: Router + Context provider + Bootstrap CSS
        ├── App.jsx             # NavBar + route table (React Router)
        ├── index.css           # custom styles
        ├── context/AppContext.jsx  # Context API: global students/courses + actions
        ├── data/initialData.js     # seed data
        ├── components/         # reusable: NavBar, Card, StudentForm, CourseForm
        └── pages/              # Home, Students, Courses, NotFound

## Concepts demonstrated
- Props: Card (title, subtitle, children, onDelete)
- State/useState: form fields, search box, context data
- useEffect: document title updates, localStorage persistence
- Forms/events: controlled inputs, onChange, onSubmit, validation
- Lists & keys: students/courses mapped with key={id}
- React Router: NavLink, Routes, Route, 404 page
- Context API: AppProvider + useApp() custom hook
- Bootstrap: responsive grid (col-md-6 col-lg-4), navbar collapse
